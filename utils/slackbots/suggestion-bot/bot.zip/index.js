const AWS = require('aws-sdk');

const dynamo = new AWS.DynamoDB.DocumentClient();
const signature = require('./verifySignature');
const message = require('./message');

const channelId = 'G015JU147RC';  // TODO: replace with #_introduceyourself channel id
// This one is a private channel used for testing.

/**
 * Demonstrates a simple HTTP endpoint using API Gateway. You have full
 * access to the request and response payload, including headers and
 * status code.
 *
 * To scan a DynamoDB table, make a GET request with the TableName as a
 * query string parameter. To put, update, or delete an item, make a POST,
 * PUT, or DELETE request respectively, passing in the payload to the
 * DynamoDB API as a JSON body.
 */
exports.handler = async (event, context) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'application/json',
    };

    try {
        switch (event.httpMethod) {
            case 'POST':
            console.log("hit the event endpoint");
            const event_body = JSON.parse(event.body);
            console.log("switch case on type");
            console.log("type: " + event_body.type);
                
            switch (event_body.type) {

              case 'url_verification': {
                // verify Events API endpoint by returning challenge if present
                console.log("sending back the challenge");
                body = { "challenge": event_body.challenge };
                break;
              }
                
              case 'event_callback': {
                // Verify the signing secret
                if (!signature.isVerified(event)) {
                  console.log("failed to verify signature");
                  throw new Error("Unverified signature. Does this message have required metadata from Slack? Have secrets been exported?");
                }
                console.log("Request is verified");
                const {type, user, channel, tab, text, bot_id, event_ts, client_msg_id} = event_body.event;
                
                if(type === 'message') {
                  
                  if(channel == channelId && typeof bot_id == 'undefined' && typeof client_msg_id !== 'undefined') { 
                    // this isn't a message from a bot and it isn't a meta-message from slack            
                    message.send(channel, text, event_ts);
                    // try {
                        
                    //   // const data = db.getData(`/${client_msg_id}`)
                    //   // const data = db.getData(`/${user}/data`);
                    //   // console.log("We've already messaged this user. Don't say hello again.");
                    //   // console.log("We've already messaged this message. Don't say hello again.");
                    // } catch(error) {
                    //   console.log("there has been an error!");
                    //   // haven't seen this user before
                    //   // DM back to the user
                    //   // const timestamp = new Date();
                    //   // db.push(`/${user}`, timestamp, true);
                    //   // db.push(`/${client_msg_id}`)
                    //   message.send(channel, text, event_ts);
                    // }; 

                  }
                 
                }
                break;
              }
              default: 
                throw new Error(`Unsupported type "${event_body.type}"`);
            }
                // if
                // body = {"msg": "hello!"}
                // body = await dynamo.put(JSON.parse(event.body)).promise();
                break;
            default:
                throw new Error(`Unsupported method "${event.httpMethod}"`);
        }
    } catch (err) {
        statusCode = '400';
        body = err.message;
    } finally {
        body = JSON.stringify(body);
    }

    return {
        statusCode,
        body,
        headers,
    };
};
